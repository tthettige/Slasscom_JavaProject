package Products;

import java.sql.SQLException;
import java.util.Scanner;

public class productView {
    static char getAnswer(){
        Scanner scan = new Scanner(System.in);
        System.out.println("----- You are in product Menu -----");
        System.out.print("Do you want change?(y/n) ");
        return scan.next().charAt(0);
    }

    public static void productView(){
        do {
            switch (displayProduct()){
                case 1:
                    addNewProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    searchProduct();
                    break;
                case 4:
                    deleteProduct();
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Invalid Input");
            }

        }while (getAnswer() == 'y');
    }

    public static int displayProduct(){

        System.out.println("1 >>>> Enter new product");
        System.out.println("2 >>>> Update Product");
        System.out.println("3 >>>> Search Product using Id");
        System.out.println("4 >>>> View All Products");
        System.out.println("5 >>>> Delete Product");
        System.out.println("6 >>>> Exit");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");
        return sc.nextInt();
    }

    public static void addNewProduct(){
        try {
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter product ID : ");
            String pid = scan.nextLine();
            System.out.println("Enter product name : ");
            String pname = scan.nextLine();
            System.out.println("Enter description of the product : ");
            String description = scan.nextLine();
            System.out.println("Enter product purchase price : ");
            Double pprice = scan.nextDouble();
            System.out.println("Enter product selling price : ");
            Double cprice = scan.nextDouble();
            System.out.println("Enter quantity : ");
            Double quantity = scan.nextDouble();


            int ap = productsController.addProduct(new Products.products(pid, pname, description, pprice, cprice, quantity));

            //message
            if (ap != 0) {
                System.out.println("Data added successfully");
            } else {
                System.out.println("not yet");
            }
            } catch (SQLException e) {
                    System.out.println(e);
                } catch (ClassNotFoundException e) {
                    System.out.println(e);
                }
            finally {
                System.out.println("After All");
            }
            }

    public static void updateProduct(){
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Product ID  : ");
            String pId = sc.next();

            Products.products pro = productsController.getProduct(pId);
            //Display Data
            System.out.println("Product name : "+ pro.getProductName());
            System.out.println("Product description : "+pro.getDescription());
            System.out.println("Product purchase price : "+pro.getPurchasePrice());
            System.out.println("Selling price : "+pro.getSellingPrice());
            System.out.println("Quantity : "+pro.getQuantity());

            //Update data
            System.out.println("--- Enter New Data ---");
            System.out.print("Enter product name : ");
            String pName = sc.next();
            System.out.print("Enter product description : ");
            String pDesc = sc.next();
            System.out.print("Enter product purchase price : ");
            double purchaseP = sc.nextDouble();
            System.out.print("Enter product selling price : ");
            double sellingP = sc.nextDouble();
            System.out.print("Enter quantity : ");
            int quantity = sc.nextInt();


            int updateP = productsController.updateProduct(pId,new Products.products(pId,pName,pDesc,purchaseP,sellingP, (double) quantity));

            if (updateP != 0){
                System.out.println("Product Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void searchProduct(){

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Product ID to Search : ");
            String pId = sc.next();

            Products.products pro = productsController.getProduct(pId);
            //Display Data
            System.out.println("Product ID : "+ pro.getProductID());
            System.out.println("Product name : "+ pro.getProductName());
            System.out.println("Product description : "+pro.getDescription());
            System.out.println("Product purchase price : "+pro.getPurchasePrice());
            System.out.println("Selling price : "+pro.getSellingPrice());
            System.out.println("Quantity : "+pro.getQuantity());

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }


        public static void deleteProduct(){


            try{
                Scanner sc = new Scanner(System.in);
                System.out.print("Enter Product ID: ");
                String pId = sc.next();

                System.out.print("Are you sure?(y/n)");
                char ans = sc.next().charAt(0);

                if (ans == 'y'){
                    productsController.deleteProduct(pId);
                    System.out.println("Product Deleted!");
                }

            }
            catch (Exception ex){
                System.out.println("Error => "+ex);
            }

        }


    }
