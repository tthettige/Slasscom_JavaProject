package Products;

public class products {
    private String productID;
    private String productName;
    private String description;
    private double purchasePrice;
    private double sellingPrice;
    private Double quantity;

    //constructor declaration

    public products(){

    }
    //constructor get using alt + insert
    public products(String productID, String productName, String description, double purchasePrice, double sellingPrice, Double quantity) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.quantity = quantity;
    }

    public products(int parseInt, String productName, String description, int purchasePrice, int sellingPrice, int quantity) {
    }




    //setters

    public void setProductID(String productID){
        this.productID=productID;
    }
    public void setProductName(String productName){
        this.productName=productName;
    }
    public void setDescription(String description){
        this.description=description;
    }
    public void setPurchasePrice(){
        this.purchasePrice=purchasePrice;
    }
    public void setSellingPrice(){
        this.sellingPrice=sellingPrice;
    }
    public void setQuantity(){
        this.quantity=quantity;
    }

    //getters
    public String getProductID(){
        return productID;
    }
    public String getProductName(){
        return productName;
    }
    public String getDescription(){
        return description;
    }
    public double getPurchasePrice(){
        return purchasePrice;
    }
    public double getSellingPrice(){
        return sellingPrice;
    }
    public Double getQuantity(){
        return quantity;
    }
}
