package Products;

import DBConnection.DBConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class productsController {

//----------------------------------Start of insert class -----------------------------------------------
   public static int addProduct(products product) throws SQLException, ClassNotFoundException {

        //connection
       Connection con = DBConnection.getConnection();

        //statement
       Statement stmt = con.createStatement();

        //insert---> values
       String insertQuery = "insert into product (product_id,product_name,description,purchase_price,selling_price,quantity) values ('"+product.getProductID()+"','"+product.getProductName()+"','"+product.getDescription()+"','"+product.getPurchasePrice()+"','"+product.getSellingPrice()+"','"+product.getQuantity()+"')";

        //run sql and return values - number of records insert
       int i = stmt.executeUpdate(insertQuery);
       System.out.println("Insert All records");
        //return no of record inserted
        return i;

    }
//----------------------------------end of insert class -----------------------------------------------


//----------------------------------Start of display class -----------------------------------------------
  public static ArrayList displayProducts(String p001) throws SQLException,ClassNotFoundException {

        products p = null;

        //declare array lis
        ArrayList products = new ArrayList();

        //connection
        Connection con = DBConnection.getConnection();

        //display data query
        String displayQuery = "select * from products";

        //statement
        Statement stmt = con.createStatement();

        //result set
        ResultSet rs = stmt.executeQuery(displayQuery);

        //display data using loop
     while (rs.next()) {
            String ProductID = rs.getString("product_id");
            String ProductName = rs.getString("product_name");
            String Description = rs.getString("description");
            int PurchasePrice = rs.getInt("purchase_price");
            int SellingPrice = rs.getInt("selling_price");
            int Quantity = rs.getInt("quantity");

            p = new products(Integer.parseInt(ProductID), ProductName, Description, PurchasePrice, SellingPrice, Quantity);

        }
        return products;
    }

//----------------------------------end of display class -----------------------------------------------

    public static products getProduct(String pID) throws ClassNotFoundException, SQLException {
        products p = null;

        //declare array lis
        ArrayList products = new ArrayList();

        //connection
        Connection con = DBConnection.getConnection();
        products pro = null;
        //display data query
        String displayQuery = "select * from products WHERE product_id='"+ pID +"'";

        //statement
        Statement stmt = con.createStatement();

        //result set
        ResultSet rs = stmt.executeQuery(displayQuery);

        //display data using loop
        while (rs.next()) {
            String ProductID = rs.getString("product_id");
            String ProductName = rs.getString("product_name");
            String Description = rs.getString("description");
            int PurchasePrice = rs.getInt("purchase_price");
            int SellingPrice = rs.getInt("selling_price");
            int Quantity = rs.getInt("quantity");

            p = new products(Integer.parseInt(ProductID), ProductName, Description, PurchasePrice, SellingPrice, Quantity);


        }
        return pro;

    }
//----------------------------------start of delete data class -----------------------------------------------
   public static int deleteProduct(String productID) throws ClassNotFoundException, SQLException{

        //connection
        Connection con = DBConnection.getConnection();

        //statement
        Statement stmt=con.createStatement();

        //delete data query
        String deleteQuery="delete from product where product_id = '"+productID+"'";

        int dp = stmt.executeUpdate(deleteQuery);
        //System.out.println("Delete successfully");
        return dp;



   }

//----------------------------------end of delete data class -----------------------------------------------

        //Update product in database
            public static int updateProduct(String productID,products pro) throws ClassNotFoundException, SQLException{
                //connection
                Connection con = DBConnection.getConnection();
                String query = "UPDATE products SET( product_name='"+ pro.getProductName() +"', description='"+ pro.getDescription() +"', purchase_price='"+ pro.getPurchasePrice() +"', selling_price='"+ pro.getSellingPrice() +"', quantity='"+ pro.getQuantity() +"')  WHERE productId='"+ productID +"'";
                Statement stmt = con.createStatement();
                return stmt.executeUpdate(query);
            }


}
