package customers;

import java.util.Date;

public class customers {
    //member variables
   private String customerID;
   private String customerName;
   private String email;
   private String address;
   private String contactNo;
   private Date dob;
   private String gender;



    public customers(int i, String customerName, String email, String address, String contactNo, String dob, String gender){

    }
    public customers(String customerID, String	customerName, String email, String	address, String	contactNo, String dob, String gender ){
        //customer_id	customer_name	email	address	contact_no	date_of_birth	gender
        this.customerID = customerID;
        this.customerName = customerName;
        this.email = email;
        this.address = address;
        this.contactNo =contactNo;
        this.gender=gender;
    }



    //setters


    public void setCustomerID(String customerID){
        this.customerID=customerID;
    }
    public void setCustomerName(String customerName){
        this.customerName=customerName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setContactNo (String contactNo) {
        this.contactNo = contactNo;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    //getter


    public String getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public Date getDob() {
        return dob;
    }

    public String getGender() {
        return gender;
    }
}
