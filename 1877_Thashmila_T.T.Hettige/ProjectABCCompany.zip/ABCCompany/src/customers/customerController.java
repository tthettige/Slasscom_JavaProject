package customers;

import DBConnection.DBConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import static java.lang.Integer.*;

public class customerController {

//---------------------------------------------------------Start of insert class ----------------------------------------------
    public static int addCustomer(customers customers) throws SQLException,ClassNotFoundException{

        //Connection
        Connection con = DBConnection.getConnection();

        //Statement
        Statement stmt = con.createStatement();

        //insert query
        //customer_id	customer_name	email	address	contact_no	date_of_birth	gender
        String insertQuery = "insert into customers (customer_id,customer_name,email,address,contact_no,date_of_birth,gender) values ('"+customers.getCustomerID()+"','"+customers.getCustomerName()+"','"+customers.getEmail()+"','"+customers.getAddress()+"','"+customers.getContactNo()+"','"+customers.getDob()+"','"+customers.getGender()+"')";

        //run sql query and return values - number of records insert
        int a = stmt.executeUpdate(insertQuery);
        System.out.println("insert all record");
        //return no of records inserted
        return  a;
    }
//-------------------------------------------------------End of insert data class -------------------------------------------------


//-------------------------------------------------------Start of view data class ------------------------------------------------
    static ArrayList displayCustomer() throws SQLException, ClassNotFoundException{

        customers c = null;

        //declare array list
        ArrayList customers = new ArrayList();

        //connection
        Connection con = DBConnection.getConnection();

        //view data query
        String viewQuery = "select * from customers";

        //statement
        Statement stmt = con.createStatement();

        //result set
        ResultSet rs = stmt.executeQuery(viewQuery);

        //display data using loop
        while (rs.next()){ //customer_id,customer_name,email,address,contact_no,date_of_birth,gender
            String customerID = rs.getString("customer_id");
            String customerName = rs.getString("customer_name");
            String email = rs.getString("email");
            String address = rs.getString("address");
            String contactNo = rs.getString("contact_no");
            String dob = rs.getString("date_of_birth");
            String gender = rs.getString("gender");

            c = new customers(parseInt(customerID),customerName,email,address,contactNo,dob,gender);
            customers.add(c);
        }
        return customers;
    }
//-----------------------------------------------------------End of view data class --------------------------------------------------

    public static customers getCustomer(String cusID) throws ClassNotFoundException, SQLException {
        //static ArrayList displayCustomer() throws SQLException, ClassNotFoundException{

        customers c = null;

//        //declare array list
//        ArrayList customers = new ArrayList();

        //connection
        Connection con = DBConnection.getConnection();

        //view data query
        String viewQuery = "select * from customers WHERE customer_id='"+ cusID +"'";

        //statement
        Statement stmt = con.createStatement();

        //result set
        ResultSet rs = stmt.executeQuery(viewQuery);

        //display data using loop
        while (rs.next()){ //customer_id,customer_name,email,address,contact_no,date_of_birth,gender
            String customerID = rs.getString("customer_id");
            String customerName = rs.getString("customer_name");
            String email = rs.getString("email");
            String address = rs.getString("address");
            String contactNo = rs.getString("contact_no");
            String dob = rs.getString("date_of_birth");
            String gender = rs.getString("gender");

            c = new customers(parseInt(customerID),customerName,email,address,contactNo,dob,gender);

        }
        return c;
    }



//----------------------------------------------------------start of delete data class -----------------------------------------------
    public static int deleteCustomer(String customerID) throws SQLException, ClassNotFoundException{
        //connection
        Connection con = DBConnection.getConnection();

        //statement
        Statement stmt = con.createStatement();

        //delete query
        String deleteQuery = "delete from customers where customer_id = '"+customerID+"'";
        int d = stmt.executeUpdate(deleteQuery);
        return d;
    }
    // -----------------------------------------------------------end of delete data class -----------------------------------------------

    public static int updateCustomer(String cusID, customers cus) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getConnection();
        String query = "UPDATE customers SET(customer_name='"+ cus.getCustomerName() +"',email='"+ cus.getEmail() +"',address='"+ cus.getAddress() +"',contact_no='"+ cus.getContactNo() +"',date_of_birth='"+ cus.getDob() +"',gender='"+ cus.getGender() +"') WHERE customerId='"+ cusID +"'";
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }




}
