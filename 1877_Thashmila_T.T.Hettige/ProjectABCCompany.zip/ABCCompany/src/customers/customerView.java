package customers;

import java.util.ArrayList;
import java.util.Scanner;

public class customerView {

    static char getAnswer(){
        Scanner scan = new Scanner(System.in);
        System.out.println("----- You are in Customer Menu -----");
        System.out.print("Do you want change?(y/n) ");
        return scan.next().charAt(0);
    }

    public static void customerView(){
        do {

            switch (customerDetails()){
                case 1:
                    newCustomer();
                    break;
                case 2:
                    updateCustomer();
                    break;
                case 3:
                    searchCustomer();
                    break;
                case 4:
                    viewAllCustomers();
                    break;
                case 5:
                    deleteCustomer();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        }while (getAnswer() == 'y' || getAnswer() == 'Y');
    }




    public static int customerDetails(){
        System.out.println("1 >>>> Enter new customer details");
        System.out.println("2 >>>> Update customer details ");
        System.out.println("3 >>>> Search customer using Id");
        System.out.println("4 >>>> View all customers");
        System.out.println("5 >>>> Delete customer using Id");
        System.out.println("6 >>>> Exit program");

        Scanner sc = new Scanner(System.in);
        System.out.print("Select a number : ");
        return sc.nextInt();
    }

    public static void newCustomer(){
        try {
            //add customer
            Scanner scan2 = new Scanner(System.in);
            System.out.println("Enter customer ID : ");
            String cid = scan2.nextLine();
            System.out.println("Enter customer name : ");
            String cname = scan2.nextLine();
            System.out.println("Enter customer mail : ");
            String cmail = scan2.nextLine();
            System.out.println("Enter customer address : ");
            String caddress = scan2.nextLine();
            System.out.println("Enter customer contact no : ");
            String cno = scan2.nextLine();
            System.out.println("Enter customer s' birth day : ");
            String dob = scan2.nextLine();
            System.out.println("Enter customer gender : ");
            String cgender = scan2.nextLine();


            int ac = customerController.addCustomer(new customers(cid, cname, cmail, caddress, cno, dob, cgender));

            //message
            if (ac != 0) {
                System.out.println("Data added successfully");
            } else {
                System.out.println("not yet");
            }

        }catch (Exception e) {
            System.out.println("Error => "+e);
            //ex.printStackTrace();
        }finally {
            System.out.println("After All");
        }
    }

    public static void updateCustomer(){
            try{
                Scanner scan = new Scanner(System.in);
                System.out.print("Enter customer ID : ");
                String cid = scan.next();

                customers cus = customerController.getCustomer(cid);
                //Display Data
                System.out.println("Customer name : "+ cus.getCustomerName());
                System.out.println("Customer email : "+ cus.getEmail());
                System.out.println("Customer address : "+ cus.getAddress());
                System.out.println("Contact Number : "+ cus.getContactNo());
                System.out.println("Date of Birth : "+ cus.getDob());
                System.out.println("Gender :"+ cus.getGender());

                //Update data
                System.out.println("--- Enter new data ---");
                System.out.print("Enter customer name : ");
                String cName = scan.next();
                System.out.print("Enter customer email : ");
                String cEmail = scan.next();
                System.out.print("Enter customer address : ");
                String cAddress = scan.next();
                System.out.print("Enter customer contact number : ");
                String cNumber = scan.next();
                System.out.print("Enter date of birth : ");
                String cdob = scan.next();
                System.out.print("Enter gender : ");
                String cgender = scan.next();

                int updatec = customerController.updateCustomer(cid,new customers( cid ,cName,cEmail,cAddress,cNumber,cdob,cgender));

                if (updatec != 0){
                    System.out.println("Customer Updated Successfully!");
                }
                else {
                    System.out.println("Something wrong!");
                }
            }
            catch (Exception ex){
                System.out.println("Error => "+ex);
            }
    }


    public static void searchCustomer(){
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Customer ID to Search : ");
            String cId = sc.next();

            customers cus = customerController.getCustomer(cId);
            //Display Data
            System.out.println("Customer name : "+ cus.getCustomerName());
            System.out.println("Customer email : "+cus.getEmail());
            System.out.println("Customer address : "+cus.getAddress());
            System.out.println("Contact Number : "+cus.getContactNo());
            System.out.println("Date of Birth : "+cus.getDob());
            System.out.println("Gender :"+ cus.getGender());

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }


    public static void viewAllCustomers(){

        try {
            ArrayList<customers> customerList = null;
            try {
                try {
                    customerList = customerController.displayCustomer();
                } catch (Exception ex) {
                    System.out.println("Error => "+ex);
                }
            } catch (Exception ex) {
                System.out.println("Error => "+ex);
            }
            assert customerList != null;
            for (customers customer : customerList) {
                Object[] rowData = {customer.getCustomerID(), customer.getCustomerName(), customer.getEmail(),customer.getAddress(),customer.getContactNo(),customer.getDob(),customer.getGender()};
                for (Object rowDatum : rowData) {
                    System.out.format("%16s", rowDatum.toString());
                }
                System.out.println();
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
        }

    }

    public static void deleteCustomer(){


        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Customer ID to Delete : ");
            String cId = sc.next();

            System.out.print("Are you sure?(y/n)");
            char ans = sc.next().charAt(0);

            if (ans == 'y'){
                customerController.deleteCustomer(cId);
                System.out.println("Customer Deleted!");
            }

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }
    }



}
