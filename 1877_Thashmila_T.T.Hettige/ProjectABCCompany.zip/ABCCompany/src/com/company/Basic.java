package com.company;

import customers.customerController;
import customers.customers;

import java.util.Scanner;

public class Basic {

    public static int displayBasic(){

        System.out.println("1) Manage Products");
        System.out.println("2) Manage Customers");
        System.out.println("3) Manage Invoices");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");

        return sc.nextInt();
    }


}
