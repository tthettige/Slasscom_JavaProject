package com.company;

import Products.products;
import customers.customers;
import com.company.Basic;

import java.util.Scanner;

import static Products.productView.productView;
import static com.company.Basic.displayBasic;
import static customers.customerView.customerView;


public class Main {

    private static customers c;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        char ans;
        do{
            switch (displayBasic()){
                case 1 :
                    productView();
                    break;
                case 2 :
                    customerView();
                    break;
                case 3 :
                    break;

                default :
                    System.out.println("Invalid Input");
            }

            System.out.println("----- You are in Main Menu -----");
            System.out.print("Do you want a do any other operation?(y/n) ");
            ans = sc.next().charAt(0);
        }while (ans == 'y' || ans == 'Y');




}
}
