package Invoice;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class invoiceView {

    static char getAnswer(){
        Scanner sc = new Scanner(System.in);
        System.out.println("----- You are in Invoice Menu -----");
        System.out.print("Do you want a do any other operation?(y/n) ");
        return sc.next().charAt(0);
    }


    public static void invoiceView(){
        do {
            switch (displayInvoice()){
                case 1:
                    addNewInvoice();
                    break;
                case 2:
                    searchInvoice();
                    break;
                case 3:
                    viewAllInvoices();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        }while (getAnswer() == 'y' || getAnswer() == 'Y');
    }

    public static int displayInvoice(){

        System.out.println("1 >>>> New Invoice");
        System.out.println("2 >>>> Search Invoice By Id");
        System.out.println("4 >>>> Exit");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");
        return sc.nextInt();
    }


    public static void addNewInvoice(){


        try{
            Scanner sc = new Scanner(System.in);
            double totalPrice = 0;
            double discount = 0;

            LocalDate today = invoiceController.getToday();
            String stringDate = today.toString();
            System.out.println("Date : " + stringDate);
            Date date =  new SimpleDateFormat("yyyy-MM-dd").parse(stringDate);

            System.out.print("Enter invoice name : ");
            String cName = sc.next();
            System.out.print("Enter product name : ");
            String pName = sc.next();
            System.out.print("Enter units per product : ");
            int units = sc.nextInt();
            System.out.print("Enter unit price : ");
            double unitPrice = sc.nextDouble();


            System.out.print("Do you want to add any discount?(y/n) : ");
            char ans = sc.next().charAt(0);

            if (ans == 'y'){
                System.out.print("Enter any discounts : ");
                discount = sc.nextDouble();

                totalPrice = (unitPrice * units)-discount;
                System.out.print("Total Price : "+totalPrice);

            }else {
                totalPrice = unitPrice * units;
                System.out.print("Total Price : "+totalPrice);
            }

            int addI = invoiceController.addInvoice(new Invoice.invoice(date, cName, pName, units , unitPrice, totalPrice, discount));

            if (addI != 0){
                System.out.println("Invoice Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
            //ex.printStackTrace();
        }finally {
            System.out.println("After All");
        }


        public static void searchInvoice(){

            try{
                Scanner sc = new Scanner(System.in);
                System.out.print("Enter Invoice ID: ");
                String iId = sc.next();

                Invoice.invoice i = invoiceController.getInvoice(iId);
                //Display Data
                System.out.println("Invoice id : "+ i.getInvoiceNumber());
                System.out.println("Invoice date : "+i.getInvoiceDate());
                System.out.println("Customer Name : "+i.getCustomerName());
                System.out.println("Product name : "+i.getProductName());
                System.out.println("Units per product : "+i.getUnitsPerProduct());
                System.out.println("Unit Price :"+ i.getUnitPrice());
                System.out.println("Total Price :"+ i.getTotalPrice());
                System.out.println("Discounts :"+ i.getDiscount());
            }
            catch (Exception ex){
                System.out.println("Error => "+ex);
            }

        }



    }







}
