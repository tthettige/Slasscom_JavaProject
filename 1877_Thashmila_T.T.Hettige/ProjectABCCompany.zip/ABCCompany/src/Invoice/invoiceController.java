package Invoice;

import DBConnection.DBConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Date;

public class invoiceController {

    //add invoice
    public static int addInvoice(invoice inv) throws ClassNotFoundException, SQLException {
        //connection
        Connection con = DBConnection.getConnection();
        //statement
        Statement stmt = con.createStatement();

        String query = "INSERT INTO invoices(invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount) VALUES('"+ inv.getInvoiceDate() +"','"+ inv.getCustomerName() +"','"+ inv.getProductName() +"','"+ inv.getUnitPrice() +"','"+ inv.getUnitsPerProduct() +"','"+ inv.getTotalPrice() +"','"+ inv.getDiscount() +"')";

        return stmt.executeUpdate(query);
    }

    //get invoice
    public static invoice getInvoice(String iID) throws SQLException, ClassNotFoundException {

        //connection
        Connection con = DBConnection.getConnection();
        //statement
        Statement stmt = con.createStatement();

        invoice inv = null;

        String viewQuery = "SELECT * FROM invoices WHERE invoiceNumber="+iID;
        //result set
        ResultSet rs = stmt.executeQuery(viewQuery);

        //invoiceNumber,invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount
        while (rs.next()){
            Date invoiceDate = rs.getDate("invoiceDate");
            String customerName = rs.getString("customerName");
            String productName = rs.getString("productName");
            int unitsPerProduct = Integer.parseInt(rs.getString("unitsPerProduct"));
            double unitPrice = Double.parseDouble(rs.getString("unitPrice"));
            double totalPrice = Double.parseDouble(rs.getString("totalPrice"));
            double discount = Double.parseDouble(rs.getString("discount"));

            inv = new invoice(invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount);
        }
        return inv;
    }
    public static LocalDate getToday(){
        return java.time.LocalDate.now();
    }
}
