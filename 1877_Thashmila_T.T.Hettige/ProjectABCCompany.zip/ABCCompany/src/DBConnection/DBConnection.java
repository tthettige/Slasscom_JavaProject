package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    static public Connection getConnection() throws ClassNotFoundException, SQLException {


        Connection con;

        //System.out.println("Program initiated");
        Class.forName("com.mysql.jdbc.Driver");
        //System.out.println("Published the driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ABCCompany", "root", "");
        System.out.println("Connected");
        return con;
    }
}
